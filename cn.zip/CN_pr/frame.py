FLAG = '01111110'  # Flag for bit stuffing  
ESC_BYTE = 'ESC'   # Escape sequence for byte stuffing  
ESC_CHAR = '!'     # Escape character for character stuffing  
FLAG_BYTE = 'FLAG'  
FLAG_CHAR = '$' 
 
def bit_stuffing(data):  
    return FLAG + data.replace('11111', '111110') + FLAG 
 
def bit_destuffing(data):  
    return data[len(FLAG):-len(FLAG)].replace('111110', '11111') 
 
def byte_stuffing(data):  
    return FLAG_BYTE + data.replace(ESC_BYTE, ESC_BYTE + 
ESC_BYTE).replace(FLAG_BYTE, ESC_BYTE + FLAG_BYTE) + FLAG_BYTE 
 
def byte_destuffing(data):  
    data = data[len(FLAG_BYTE):-len(FLAG_BYTE)]  
    return data.replace(ESC_BYTE + FLAG_BYTE, FLAG_BYTE).replace(ESC_BYTE + 
ESC_BYTE, ESC_BYTE) 
 
def char_stuffing(data):  
    return FLAG_CHAR + data.replace(ESC_CHAR, ESC_CHAR + 
ESC_CHAR).replace(FLAG_CHAR, ESC_CHAR + FLAG_CHAR) + FLAG_CHAR 
 
def char_destuffing(data):  
    data = data[len(FLAG_CHAR):-len(FLAG_CHAR)]  
    return data.replace(ESC_CHAR + FLAG_CHAR, FLAG_CHAR).replace(ESC_CHAR + 
ESC_CHAR, ESC_CHAR) 
 
def character_count_framing(data):  
    return f"{len(data)}:{data}" 
 
def character_count_deframing(data):  
    message = data.split(':', 1) 
    return message 
 
if __name__ == "__main__":  
 bit_data =input("Enter Data for bit Stuffing:")  
 byte_data =input("Enter Data for byte Stuffing:") 
 char_data = input("Enter Data for character Stuffing:")  
 count_data =input("Enter Data for Character Count:") 
 
print(f"Bit Stuffed: {bit_stuffing(bit_data)}")  
print(f"Bit Destuffed: {bit_destuffing(bit_stuffing(bit_data))}")  
print(f"\nByte Stuffed: {byte_stuffing(byte_data)}")  
print(f"Byte Destuffed: {byte_destuffing(byte_stuffing(byte_data))}")  
print(f"\nCharacter Stuffed: {char_stuffing(char_data)}")  
print(f"Character Destuffed: {char_destuffing(char_stuffing(char_data))}")  
print(f"\nCharacter Count Framed: {character_count_framing(count_data)}")  
print(f"Character Count Deframed: {character_count_deframing(character_count_framing(count_data))}") 
 
