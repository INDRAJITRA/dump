def hamming_encode(data_bits):
    m = len(data_bits)
    r = 0

    # Calculate number of parity bits required
    while (2 ** r) < (m + r + 1):
        r += 1

    # Initialize hamming code array
    hamming_code = [0] * (m + r)

    # Place data bits in non-parity positions
    j = 0
    for i in range(1, len(hamming_code) + 1):
        if i & (i - 1) == 0:
            continue
        hamming_code[i - 1] = data_bits[j]
        j += 1

    # Calculate parity bits
    for i in range(r):
        pos = 2 ** i - 1
        parity = 0

        for j in range(pos, len(hamming_code), 2 * (pos + 1)):
            parity ^= sum(hamming_code[j:j + pos + 1]) % 2

        hamming_code[pos] = parity

    return hamming_code


def hamming_correct(hamming_code):
    r = 0

    # Calculate number of parity bits
    while (2 ** r) < len(hamming_code) + 1:
        r += 1

    error_pos = 0

    # Detect error position
    for i in range(r):
        pos = 2 ** i - 1
        parity = 0

        for j in range(pos, len(hamming_code), 2 * (pos + 1)):
            parity ^= sum(hamming_code[j:j + pos + 1]) % 2

        if parity != 0:
            error_pos += pos + 1

    # Correct error if found
    if error_pos:
        hamming_code[error_pos - 1] ^= 1
        print(f"Error detected at position {error_pos}, corrected.")
    else:
        print("No error detected.")

    return hamming_code


def main():
    data_bits = [1, 0, 1, 1]
    print("Data Bits:", data_bits)

    hamming_code = hamming_encode(data_bits)
    print("Hamming Code:", hamming_code)

    # Introduce an error
    hamming_code[2] ^= 1
    print("With Error:", hamming_code)

    corrected_code = hamming_correct(hamming_code)
    print("Corrected Code:", corrected_code)


if __name__ == "__main__":
    main()
