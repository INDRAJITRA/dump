def xor_operation(a, b):
    result = ""

    for i, j in zip(a, b):
        if i == j:
            result += '0'
        else:
            result += '1'

    return result


def crc_division(data, divisor):
    n = len(divisor)
    temp = data[:n]

    for i in range(n, len(data)):

        if temp[0] == '1':
            temp = xor_operation(temp, divisor)
        else:
            temp = xor_operation(temp, '0' * n)

        temp = temp[1:] + data[i]

    # Final XOR
    if temp[0] == '1':
        temp = xor_operation(temp, divisor)
    else:
        temp = xor_operation(temp, '0' * n)

    return temp[1:]


def crc_encode(data, divisor):
    appended_data = data + '0' * (len(divisor) - 1)

    remainder = crc_division(appended_data, divisor)

    return data + remainder


# Main Program
data = input("Enter data bits: ")
divisor = input("Enter divisor: ")

if not (set(data) <= {'0', '1'} and set(divisor) <= {'0', '1'}):
    print("Error: Enter only binary values!")

else:
    encoded_data = crc_encode(data, divisor)

    print("Encoded Data with CRC:", encoded_data)
